package com.example.myupdaterecycler;

import android.net.Uri;

public class MyItem {
    private Uri uriImage;
    private String firstName;
    private String lastName;
    private String course;
    private String year;
    private int id;

    public MyItem(Uri uriImage, String firstName,
                  String lastName, String course, String year, int id) {
        this.uriImage = uriImage;
        this.firstName = firstName;
        this.lastName = lastName;
        this.course = course;
        this.year = year;
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }
    public String getLastName() { return lastName; }
    public void setFirstName(String name) {this.firstName = name;}
    public Uri getUriImage() {
        return uriImage;
    }
    public void setUriImage(Uri uriImage) {this.uriImage = uriImage; }
    public MyItem() {}
    public String getYear() {
        return year;
    }
    public String getCourse() {
        return course;
    }
    public int getId() { return id;}
}